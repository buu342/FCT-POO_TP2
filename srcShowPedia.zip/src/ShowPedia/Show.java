package ShowPedia;

public interface Show {

}
