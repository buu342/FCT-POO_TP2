package ShowPedia;

public interface Character {

}
