package ShowPedia;

public interface Episode {

}
