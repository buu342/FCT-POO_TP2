package ShowPedia;

public interface ShowPedia {

}
