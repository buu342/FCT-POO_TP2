package ShowPedia;

public class EpisodeClass implements Episode {

}
