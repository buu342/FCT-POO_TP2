package ShowPedia;

import java.util.HashMap;
import java.util.Map;


public class ShowClass implements Show {

    private Map<Integer, HashMap<Integer, Episode>> seasons;
    
    public ShowClass() {
        seasons = new HashMap<Integer, HashMap<Integer,Episode>>();
    }
    
}