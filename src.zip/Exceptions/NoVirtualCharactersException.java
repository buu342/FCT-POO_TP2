/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Virtual character doesn't exist
 */

package Exceptions;

public class NoVirtualCharactersException extends Exception {

	private static final long serialVersionUID = 1L;

}
