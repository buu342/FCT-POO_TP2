/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Episode doesn't exist
 */

package Exceptions;

public class NoEpisodeException extends Exception {

	private static final long serialVersionUID = 1L;

}
