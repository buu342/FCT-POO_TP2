/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Quote doesn't exist
 */

package Exceptions;

public class UnexistingQuoteException extends Exception {

	private static final long serialVersionUID = 1L;

}
