/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Character is in a relationship with itself
 */

package Exceptions;

public class SingleRelationshipException extends Exception {

    private static final long serialVersionUID = 1L;

}
