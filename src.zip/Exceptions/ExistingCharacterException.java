/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Character has already been registered in ShowPedia.
 */

package Exceptions;

public class ExistingCharacterException extends Exception {

    private static final long serialVersionUID = 1L;

}
