/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - The show has not been registered in ShowPedia.
 */

package Exceptions;

public class NonExistingShowException extends Exception {

    private static final long serialVersionUID = 1L;

}
