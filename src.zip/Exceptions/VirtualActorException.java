/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - A character is virtual
 */

package Exceptions;

public class VirtualActorException extends Exception {
	private static final long serialVersionUID = 1L;

}
