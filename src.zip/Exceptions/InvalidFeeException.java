/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - The fee value provided by the user is smaller than 0.
 */

package Exceptions;

public class InvalidFeeException extends Exception {

    private static final long serialVersionUID = 1L;

}
