/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Character is inputted twice
 */

package Exceptions;

public class DuplicateCharacterException extends Exception {

	private static final long serialVersionUID = 1L;

}
