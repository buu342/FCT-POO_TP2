/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - No show has been selected by the user.
 */

package Exceptions;

public class NoShowSelectedException extends Exception {

    private static final long serialVersionUID = 1L;

}
