/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Character doesn't exist
 */

package Exceptions;

public class NoCharacterException extends Exception {

	private static final long serialVersionUID = 1L;

}
