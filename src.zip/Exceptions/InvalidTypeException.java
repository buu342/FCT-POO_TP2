/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - The type of character requested is incorrect.
 */

package Exceptions;

public class InvalidTypeException extends Exception {

    private static final long serialVersionUID = 1L;

}
