/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - Romance character 2 doesn't exist
 */

package Exceptions;

public class NoChildException extends Exception {

	private static final long serialVersionUID = 1L;

}
