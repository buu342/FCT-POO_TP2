/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - The season interval is incorrect
 */

package Exceptions;

public class InvalidIntervalException extends Exception {

	private static final long serialVersionUID = 1L;

}
