/**
 * @author Andre Enes 51099
 * @author Lourenco Soares 54530
 * Exception - The requested season does not exist.
 */

package Exceptions;

public class NoSeasonException extends Exception {

    private static final long serialVersionUID = 1L;

}
