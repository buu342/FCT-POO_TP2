package Supermarket;

public interface Item {
    
    String getName();
    
    int getSize();
    
    int getPrice();

}
