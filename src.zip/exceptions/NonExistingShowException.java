package exceptions;

public class NonExistingShowException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
