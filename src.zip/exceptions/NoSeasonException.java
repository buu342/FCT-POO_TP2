package exceptions;

public class NoSeasonException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
