import java.util.Scanner;
import ShowPedia.*;
import exceptions.*;
 

public class Main 
{
    // Command Constants
    public static final String COMMAND_SHOW_ADD              	= "ADDSHOW";   
    public static final String COMMAND_SHOW_CURRENT             = "CURRENTSHOW";
    public static final String COMMAND_SHOW_CURR                = "CURRENTSHOW";
    public static final String COMMAND_SHOW_SWITCHTO            = "SWITCHTOSHOW";
    public static final String COMMAND_SEASON_ADD               = "ADDSEASON";
    public static final String COMMAND_SEASON_OUTLINE           = "SEASONSOUTLINE";
    public static final String COMMAND_EPISODE_ADD              = "ADDEPISODE";
    public static final String COMMAND_CHARACTER_ADD            = "ADDCHARACTER";
    public static final String COMMAND_CHARACTER_RESUME         = "CHARACTERRESUME";
    public static final String COMMAND_CHARACTER_COMPARE        = "HOWARETHESETWORELATED";
    public static final String COMMAND_CHARACTER_FILMOGRAPHY    = "HOWARETHESETWORELATED";
    public static final String COMMAND_RELATIONSHIP_ADD         = "ADDRELATIONSHIP";
    public static final String COMMAND_ROMANCE_ADD              = "ADDROMANCE";
    public static final String COMMAND_EVENT_ADD                = "ADDEVENT";
    public static final String COMMAND_QUOTE_QUOTER             = "FAMOUSQUOTES";
    public static final String COMMAND_ACTOR_ROMANCE            = "MOSTROMANTIC";
    public static final String COMMAND_KINGCGI                  = "KINGOFCGI";
    public static final String COMMAND_HELP                     = "HELP";
    public static final String COMMAND_QUIT                     = "EXIT";
     
     // Message Constants
    public static final String MESSAGE_UNKNOWN_CMD      = "Unknown command. Type help to see available commands.";
    public static final String NO_SHOW_SELECTED     	= "No show is selected!";
    public static final String NO_SEASON     			= "Unknown Season!";
    public static final String EXISTING_SHOW    		= "Show already exists!";
    public static final String NON_EXISTING_SHOW    	= "Unknown show!";
    public static final String MESSAGE_EXIT             = "Bye!";
    public static final String MESSAGE_HELP             = "currentShow - show the current show\r\n" + 
            "addShow - add a new show\r\n" + 
            "switchToShow - change the context to a particular show\r\n" + 
            "addSeason - add a new season to the current show\r\n" + 
            "addEpisode - add a new episode to a particular season of the current show\r\n" + 
            "addCharacter - add a new character to a show\r\n" + 
            "addRelationship - add a family relationship between characters\r\n" + 
            "addRomance - add a romantic relationship between characters\r\n" + 
            "addEvent - add a significant event involving at least one character\r\n" + 
            "addQuote - add a new quote to a character\r\n" + 
            "seasonsOutline - outline the contents of the selected seasons for the selected show\r\n" + 
            "characterResume - outline the main information on a specific character\r\n" + 
            "howAreTheseTwoRelated - find out if and how two characters may be related\r\n" + 
            "famousQuotes - find out which character(s) said a particular quote\r\n" + 
            "alsoAppearsOn - which other shows and roles is the same actor on?\r\n" + 
            "mostRomantic - find out who is at least as romantic as X\r\n" + 
            "kingOfCGI - find out which company has earned more revenue with their CGI virtual actors\r\n" + 
            "help - shows the available commands\r\n" + 
            "exit - terminates the execution of the program";

     public static void main(String[] args) 
     {   
         Scanner in = new Scanner(System.in);
         ShowPedia sPedia = new ShowPediaClass();
         String comm = getCommand(in);
      
         while (!comm.equals(COMMAND_QUIT)) {
             switch (comm) {
                 case COMMAND_HELP:
                     showHelp(sPedia);
                     break;
                 case COMMAND_SHOW_SWITCHTO:
                     switchToShow(in,sPedia);
                     break;
                 case COMMAND_SHOW_ADD:
                     addShow(in, sPedia);
                     break;
                 case COMMAND_EPISODE_ADD:
                     addEpisode(in, sPedia);
                     break;
                 case COMMAND_SEASON_ADD:
                     addSeason(in, sPedia);
                     break;
                 case COMMAND_SHOW_CURRENT:
                	 currentShow(sPedia);
                	 break;
                 default:
                     System.out.println(MESSAGE_UNKNOWN_CMD);
                     break;
             }
             System.out.println();
             comm = getCommand(in);
         }
         System.out.println(MESSAGE_EXIT);
         System.out.println();
         in.close();
     }
    
    private static void addEpisode(Scanner in, ShowPedia sPedia) {
		int season = in.nextInt();
		String episode = in.nextLine().trim();
		
		try {
			sPedia.addEpisode(season, episode);
			Show tmp = sPedia.getCurrent();
			System.out.printf("%s S%d, Ep%d: %s.", season, tmp.getSeason(season).size(), episode);
		}catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		}catch (NoSeasonException e) {
			System.out.println(NO_SEASON);
		}
		
	}

	
	private static void addSeason(Scanner in, ShowPedia sPedia) {
    	try {
			sPedia.addSeason();
			currentShow(sPedia);
		}catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		}
	}

	private static void switchToShow(Scanner in, ShowPedia sPedia) {
    	String show = in.nextLine();
    	try {
			sPedia.switchToShow(show);
			currentShow(sPedia);
		}catch(NonExistingShowException e) {
			System.out.println(NON_EXISTING_SHOW);
		}
	}

	private static void addShow(Scanner in, ShowPedia sPedia) {
		String show = in.nextLine();
    	try {
			sPedia.addShow(show);
			System.out.printf("%s created.", show);
		}catch(ExistingShowException e) {
			System.out.println(EXISTING_SHOW);
		}
		
	}

	private static void currentShow(ShowPedia sPedia) {
    	try {
			Show tmp = sPedia.getCurrent();
			System.out.printf("%s. Seasons: %d Episodes: %d", tmp.getName(), tmp.getNrSeasons(), tmp.getNrEpisodes());
		}catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		}
    	
	}

	private static String getCommand(Scanner in) {
        String input;
        input = in.nextLine().toUpperCase();
        return input;
    }
    
    private static void showHelp(ShowPedia sPedia) {
        System.out.println(MESSAGE_HELP);
    }
        
    
}
