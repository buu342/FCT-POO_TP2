package ShowPedia;

public class ActorClass implements Actor {

}
