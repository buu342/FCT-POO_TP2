package ShowPedia;

public class CharacterClass implements Character {

}
