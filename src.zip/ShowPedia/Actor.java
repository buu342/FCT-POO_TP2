package ShowPedia;

public interface Actor {

}
